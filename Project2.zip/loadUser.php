<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'dbFuncs.php';

if (!isset($_SESSION['fname'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$pdo = connectDB();

// Get user info
$stmt = $pdo->prepare("SELECT studentID, fname, lname, email, phone FROM students WHERE fname = :fname LIMIT 1");
$stmt->execute(['fname' => $_SESSION['fname']]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['error' => 'User not found']);
    exit;
}

// Now get schedule info
$stmt = $pdo->prepare("SELECT subject, date, time FROM sessions WHERE studentID = :id ORDER BY date");
$stmt->execute(['id' => $user['studentID']]);
$sessions = $stmt->fetchAll();

// Return full user info + schedule
echo json_encode([
    'fname' => $user['fname'],
    'lname' => $user['lname'],
    'email' => $user['email'],
    'phone' => $user['phone'],
    'sessions' => $sessions
]);
