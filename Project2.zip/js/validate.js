function validateEmail(id) 
{
	let email=id.value;
	var msgId=document.getElementById("emailMsg");
	var good=false;
	if (/^[A-Za-z0-9.-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email)) 
	{
		good=true;
		msgId.innerHTML="";
	}
	else
	{
		good=false;
		msgId.innerHTML="Please enter a valid email";
	}



	return good;

}

function validatePassword(id) {
	let password = id.value;
	let msgId = document.getElementById("passwordMsg");
	let good = false;

	if (password.length < 6) {
		msgId.innerHTML = "Password must be at least 6 characters.";
	} else if (/^[A-Za-z]+$/.test(password)) {
		msgId.innerHTML = "Password cannot be only letters.";
	} else if (/^\d+$/.test(password)) {
		msgId.innerHTML = "Password cannot be only numbers.";
	} else {
		msgId.innerHTML = "";
		good = true;
	}

	return good;
}


function validate() {
	let eId=document.getElementById("email");
	let cId=document.getElementById("card");
	let submit=validateEmail(eId)&& validateCard(cId);
	if(!submit)
		document.getElementById("formMsg").innerHTML="Please provide email and card";
	return submit;
}





