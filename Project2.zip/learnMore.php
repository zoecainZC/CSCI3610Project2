<?php
include("pageFormat.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Learn More</title>
  <link rel="stylesheet" href="css/learnMore.css">
</head>
<body>
    <?php pageHeader("Ray's Tutoring"); ?>
  <main>
    <br>

    <img src="./images/yellowJacket.png" alt="GA Tech Mascot">

  <div class = "text-container">

  <h4>Overview</h4>
  <p>Ray has been helping students succed for over 5 years and has experience in a wide range of courses in both high school and college. While he currently works as a private tutor, Ray also has years of experience helping students through his alma mater, The Georgia Institute of Technology. As an award-winning tutor, he is dedicated to helping students reach their full potential. Continue reading to learn more about Ray's qualifications and history.</p>

  <h4>Undergraduate Years</h4>
  <p>Ray first began tutoring in 2020, working in Georgia Tech's Center for Academic Success. He routinely held one-on-one sessions with students needing help with physics, math, and programming. Ray also spent time working at the centers help desk, answering a wide range of questions for students who visited the center. After working in the center for 2 years, he was nominated by his fellow students as 2022's Outstanding Tutor, and was granted the honor by the university's faculty. Shortly after, he graduated Summa Cum Laude with a Bachelor of Science in Physics.</p>

  <h4>Graduate School</h4>
  <p>In the fall of 2022, Ray chose to continue his education by joining Georgia Tech's <a href= "https://qbios.gatech.edu/">Interdisciplinary Graduate Program in Quantitave Biosciences (QBioS)</a>. During his time in the program, he served as a teaching assistant for both Physics I and Foundations of Quantitative Bioscience (the PhD program's first course), where he held group tutoring sessions for upwards of 150 students each week, along with conducting 4-hour labratory periods. It was during this time that Ray began working as an independent tutor, and he has since accumulated over 500 hours of tutoring experience, not including the time spent in the institute's Center for Academic Success. Ray graduated with his PhD in May of 2025. </p> 

  <h4>Today</h4>
  <p>Today, Ray continues to work as an independent tutor for high school and college students while working as a postdoctoral fellow in the same lab where he earned his PhD. His work focuses on antibiotic susceptibility testing, and he can often be found creating simulations for microbial communities under stress. He is a published author in the field, with 2 papers currently out and 2 under review.</p>
</div>

<br>

<div id="courses">
  <h3>Courses</h3>

  <div class="courses-tabs">
  <div class="tab-buttons">
      <button class="tab-button active" onclick="showTab('physics')">Physics</button>
      <button class="tab-button" onclick="showTab('math')">Mathematics</button>
      <button class="tab-button" onclick="showTab('programming')">Programming</button>
      <button class="tab-button" onclick="showTab('hs')">High School</button>
      <button class="tab-button" onclick="showTab('misc')">Misc.</button>
  </div>
  <div class="tab-content">
      <div id="physics" class="tab-content-item active">
      <ul>
          <li>Physics I: Introduction to Mechanics</li>
          <li>Physics II: Introduction to Electromagnetism</li>
          <li>Physics III: Introduction to Modern Physics</li>
          <li>Quantam Mechanics I</li>
          <li>Thermodynamics</li>  
      </ul>
      </div>

      <div id="math" class="tab-content-item">
      <ul>
        <li>Calculus I: Introduction to Differential Calculus</li>
        <li>Calculus II: Introduction to Integral Calculus</li>
        <li>Calculus III: Multivariable Calculus</li>
        <li>College Algebra</li>
        <li>Differential Equations</li>
      </ul>
    </div>

    <div id="programming" class="tab-content-item">
      <ul>
        <li>Introduction to Machine Learning</li>
        <li>Introduction to MATLAB</li>
        <li>Introduction to Python</li>
        <li>Advanced Python</li>
        <li>Introduction to Programming</li>
        <li>Data Structures</li>
        <li>Data Science & Machine Learning</li>
      </ul>
    </div>

    <div id="hs" class="tab-content-item">
      <ul>
        <li>A.P. Physics</li>
        <li>Honors Physics</li>
        <li>A.P. Calculus BC</li>
        <li>Geometry</li>
        <li>SAT Prep (Math)</li>
        <li>ACT Prep (Math, Science)</li>
      </ul>
    </div>

    <div id="misc" class="tab-content-item">
      <ul>
          <li>Foundations of Quantitative Bioscience</li>
          <li>Statics</li>
          <li>Engineering Thermodynamics</li>
      </ul>
    </div>
</div>
</div>


  </main>

  <br><br>

<?php pageFooter(); ?>

<script src="js/learnMore.js" defer></script>

</body>
</html>
