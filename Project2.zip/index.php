<?php
include("pageFormat.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ray's Tutoring</title>
  <link rel="stylesheet" href="css/index.css">
</head>
<body>
  <?php pageHeader("Ray's Tutoring"); ?>
  <main>
    <h2>Welcome to Ray's Tutoring!</h2>
    <p>Your success starts here.</p>

    <div class="image-container">
      <img src="./images/techTower.jpg" alt="Tech Tower">
      <img src="./images/RayHeadshot.jpg" alt="Ray Headshot">
    </div>

    <br>

    <div class = "text-container">
      <h3> Ray first began tutoring during his time as an undergraduate physics student at the Gerogia Institute of Technology in 2019. Today, he has over 5 years of experience helping students in various areas, including: <br> </h3>
      <ul>
          <li>Physics</li>
          <li>Mathematics</a></li>
          <li>Programming</li>
          <li>SAT Prep</li>
      </ul>

      <p>** For a complete list of courses that Ray has experience helping with, click <a href="learnMore.php#courses">here</a>.</p><br>
      <p>For more information about Ray and his qualifications, pleast visit the Learn More tab. Sign up, login, or contact Ray below if you are interested in scheduling a session!</p>
      <br><br>

      <div class="icon-container">
      <img src="./images/atom.png" alt="atom" class="icon-image">
      <img src="./images/calculator.png" alt="calculator" class="icon-image">
      <img src="./images/mouse.png" alt="mouse" class="icon-image">
      </div>

      <br>

    </div>

  </main>

 <?php pageFooter(); ?>


</body>
</html>
