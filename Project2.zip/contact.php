<?php
include("pageFormat.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact</title>
  <link rel="stylesheet" href="css/learnMore.css">
  <style>
      .card {
      max-width: 700px;
      margin: auto;
      padding: 20px;
      font-family: Georgia, serif;
      background-color: #f9f9f9;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    h2 {
        text-align: center;
    }
  </style>
</head>
<body>
    <?php pageHeader("Ray's Tutoring"); ?>

    <br>
  <div class="card">
  
  <h2>Contact the Tutor</h2>
    <p>If you have questions about your sessions, need help scheduling, or would like to learn more, please reach out:</p>

    <div class="contact-info">
      <p><strong>Phone:</strong> (123) 456-7890</p>
      <p><strong>Email:</strong> <a href="mailto:raystutoring@example.com">raystutoring@example.com</a></p>
      <p><strong>Best Hours to Contact:</strong> Monday - Friday, 10:00 AM – 5:00 PM</p>
    </div>

  </div>

  <br><br><br>

<?php pageFooter(); ?>


</body>
</html>
