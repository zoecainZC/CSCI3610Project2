<?php
  session_start();
  if (isset($_SESSION['fname'])) {
    echo "You have logged in as " . $_SESSION['fname'];
    echo "<br> <a href='./index.php' class='btn btn-primary'>Back to Home</a>";
    die();
  }
  
  include("pageFormat.php");

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-6n5384xqQ1ao40CA+858RXPxPg6fy4IWwTIah0E263Xefc)]SAwi0gFAW/dAi563Xn" crossorigin="anonymous">
    <title>LOGIN</title>
    <link rel="stylesheet" href="css/login.css">
  </head>
  <body>
      <?php pageHeader("Ray's Tutoring"); ?>
    <br><br>
    <div class="container">

      <form action="./login.php" method="POST"> <!-- form for the user to enter their email and password -->
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" name="email" class="form-control" id="email" placeholder="Enter email">
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" name="pwd" class="form-control" id="pwd" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
        
         <br>
        <p>Don't have an account? Sign up <a href="signup.php">here</a></p>
        <a href="./index.php">Back To Home</a> 
        
      <?php
        require_once 'dbFuncs.php';
        if (isset($_POST["email"]) && isset($_POST["pwd"])) {
          $email = $_POST["email"];
          $pwd = $_POST["pwd"];

          // Secure DB connection
          $pdo = connectDB();
          $query = "SELECT * FROM students WHERE email = :email AND password = SHA1(:pwd)";
          $stmt = $pdo->prepare($query);
          $stmt->execute(['email' => $email, 'pwd' => $pwd]);
          $arr = $stmt->fetchAll();

          if (count($arr) == 1) {
            $_SESSION['fname'] = $arr[0]["fname"];
            $_SESSION['level'] = $arr[0]["level"];
            setcookie("user_logged_in", $_SESSION['fname'], time() + (86400 * 30), "/"); // set cookie for 30 days

            if ($_SESSION['level'] == 0) {
              header('Location: ./index.php');
            } else {
              header('Location: ./index.php');
            }
            exit;
          } else {
            echo "<p class=\"text-danger\">Incorrect email or password</p>"; // error message if credentials are invalid
          }
        }
      ?>
      
      
    </div><br><br><br>
    
    <?php pageFooter(); ?>

  </body>
</html>
