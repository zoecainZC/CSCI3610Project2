<?php
  session_start();
  if (isset($_SESSION['fname'])) {
    echo "You have logged in as " . $_SESSION['fname'];
    echo "<br> <a href='./index.php' class='btn btn-primary'>Back to Home</a>";
    die();
  }
  
  include("pageFormat.php");

?>

<!--
    This file handles the user login functionality. If the user is already logged in, it 
    displays a welcome message with their name. If the user is not logged in, it displays a 
    form where they can enter their email and password. If the credentials are valid, 2 
    things happen:
     * their name and level are stored in the session
     * a cookie is set to remember the user for 30 days unless they logout
    If credentials are invalid, an error message is shown.
-->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-6n5384xqQ1ao40CA+858RXPxPg6fy4IWwTIah0E263Xefc)]SAwi0gFAW/dAi563Xn" crossorigin="anonymous">
    <title>LOGIN</title>
    
    <style>
        .btn-primary {
            text-align: center !important;
        text-decoration: none !important;
        background-color: #2e7d32 !important; 
        color: white !important;
        padding: 10px 20px !important;
        border-radius: 0px !important;
        font-size: 18px !important;
        font-weight: bold !important;
        font-family: Georgia !important;
        transition: background 0.3s ease !important;
        border: none !important;
        cursor: pointer !important;
        margin-bottom:20px !important;
        }
        
        .btn-primary:hover {
        background-color: #b6e2a1 !important;
      }
      
      header {
      background: linear-gradient(to right, #b6e2a1, #2e7d32);
      color: white;
      padding: 5px 0;
      text-align: center;
    }
    
    a {
        color: #2e7d32;
    }
    
    a:hover {
        color: #b6e2a1;
    }

    h1 {
      font-size: 70px;
      font-family: Georgia;
    }

    h2 {
      font-family: Georgia;
    }

    h3 {
      font-family: Georgia;
      font-size: 20px;
      font-weight: normal;
    }

    p {
      font-family: Georgia;
      font-size: 20px;
    }

    nav {
      background: rgba(0, 0, 0, 0.1);
      padding: 15px 0;
    }

    nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
    }
    
    nav ul li {
      margin: 0 25px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-family: Georgia;
      font-size: 20px;
    }
    
    nav ul li a:hover {
      color: #b6e2a1; /* soft green on hover */
    }
    
    footer {
      background: linear-gradient(to right, #b6e2a1, #2e7d32);
      color: white;
      text-align: center;
      padding: 50px 0;
      width: 100%;
    }
    
    footer p {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px; /* controls spacing between items */
  font-size: 20px;
  margin: 0;
}


    </style>

  </head>
  <body>
      <?php pageHeader("Ray's Tutoring"); ?>
    <br><br>
    <div class="container">

      <form action="./login.php" method="POST"> <!-- form for the user to enter their email and password -->
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" name="email" class="form-control" id="email" placeholder="Enter email">
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" name="pwd" class="form-control" id="pwd" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
        
         <br>
        <p>Don't have an account? Sign up <a href="signup.php">here</a></p>
        <a href="./index.php">Back To Home</a> 
        
      <?php
        require_once 'dbFuncs.php';
        if (isset($_POST["email"]) && isset($_POST["pwd"])) {
          $email = $_POST["email"];
          $pwd = $_POST["pwd"];

          // Secure DB connection
          $pdo = connectDB();
          $query = "SELECT * FROM students WHERE email = :email AND password = SHA1(:pwd)";
          $stmt = $pdo->prepare($query);
          $stmt->execute(['email' => $email, 'pwd' => $pwd]);
          $arr = $stmt->fetchAll();

          if (count($arr) == 1) {
            $_SESSION['fname'] = $arr[0]["fname"];
            $_SESSION['level'] = $arr[0]["level"];
            setcookie("user_logged_in", $_SESSION['fname'], time() + (86400 * 30), "/"); // set cookie for 30 days

            if ($_SESSION['level'] == 0) {
              header('Location: ./index.php');
            } else {
              header('Location: ./index.php');
            }
            exit;
          } else {
            echo "<p class=\"text-danger\">Incorrect email or password</p>"; // error message if credentials are invalid
          }
        }
      ?>
      
      
    </div><br><br><br>
    
    <?php pageFooter(); ?>

  </body>
</html>
