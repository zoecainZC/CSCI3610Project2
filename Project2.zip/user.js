    // ***** POPUP FUNCTIONS *****
    function openPopup() {
      document.getElementById("popup-overlay").style.display = "flex";
      document.getElementById("profile-container").classList.add("blur");
      
      const form = document.getElementById("edit-profile-form");
      if (form && !form.dataset.listenerAdded) {
      form.addEventListener("submit", submitProfileEdit);
      form.dataset.listenerAdded = "true"; // Prevent duplicate listeners
      }
    }

    function closePopup() {
      document.getElementById("popup-overlay").style.display = "none";
      //document.getElementById("profile-container").classList.remove("blur");
    }
    
    // ***** AJAX REQUEST FUNCTION *****
    async function makeAjaxRequest(url, method, data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(url, options);
        
        // DEBUG: See what the server returned before parsing JSON 
        const responseText = await response.text();
        console.log("Raw response:", responseText);

        let result;
        try {
            result = JSON.parse(responseText);
        } catch (parseError) {
            throw new Error("Invalid JSON response: " + responseText);
        }

        if (!response.ok || !result.success) {
            throw new Error(result.message || `HTTP error! status: ${response.status}`);
        }

        return result;
    } catch (error) {
        console.error('Error:', error);
        return { success: false, message: error.message || 'An error occurred while making the request.' };
    }
}

    
    // ***** PROFILE EDIT SUBMISSION *****
    async function submitProfileEdit(event) {
  event.preventDefault();

  const form = event.target;
  const email = form.querySelector("#edit-email").value.trim();
  const phone = form.querySelector("#edit-phone").value.trim();

  // email and phone validation
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  if (!phone || phone.length < 7) {
    alert("Please enter a valid phone number.");
    return;
  }

  const data = { email, phone };

  const result = await makeAjaxRequest("editProfileHandler.php", "POST", data);

  if (result.success) {
    // update profile values on the page
    document.getElementById("display-email").textContent = email;
    document.getElementById("display-phone").textContent = phone;

    closePopup();
    
    form.reset();

    alert("Profile updated successfully.");
  } else {
    alert(result.message || "An error occurred.");
  }
}

    
  const tips = [
    "Break study sessions into 25-minute intervals.",
    "Teach the material to someone else.",
    "Avoid multitasking while studying. Stay focused on one topic at a time.",
    "Take short breaks every hour to refresh your brain.",
    "Summarize information in your own words.",
    "Use active recall: quiz yourself instead of just rereading notes.",
    "Study in the same place every time to build a routine.",
    "Don’t cram! Review regularly throughout the week."
  ];

  // pick new random tip not saved in sessionStorage
  function getNewTip() {
    let lastTipIndex = sessionStorage.getItem("lastStudyTipIndex");
    let newIndex;

    do {
      newIndex = Math.floor(Math.random() * tips.length);
    } while (newIndex == lastTipIndex && tips.length > 1);

    sessionStorage.setItem("lastStudyTipIndex", newIndex);
    return tips[newIndex];
  }

  function displayStudyTip() {
    const tipText = getNewTip();
    const tipCardHTML = `
      
        <h4 style="margin-bottom: 0.5rem;">Study Tip</h4>
        <p style="margin: 0;">${tipText}</p>
    `;
    document.getElementById("studyTip").innerHTML = tipCardHTML;
  }

  document.addEventListener("DOMContentLoaded", displayStudyTip);
  

function updateCountdowns() {
    const now = new Date().getTime();
    document.querySelectorAll('.exam-date').forEach(function(el) {
      const examDateStr = el.dataset.date;
      const examDate = new Date(examDateStr + "T00:00:00").getTime();  // Treat as local date
      const row = el.closest('tr');
      const countdownEl = row.querySelector('.countdown');

      const diff = examDate - now;
      if (diff <= 0) {
        countdownEl.textContent = "Exam day!";
      } else {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / (1000 * 60)) % 60);
        countdownEl.textContent = `${days}d ${hours}h ${minutes}m remaining`;
      }
    });
  }

  updateCountdowns();
  setInterval(updateCountdowns, 60000); // update every 60 seconds
 
   document.getElementById('openModalBtn').onclick = function() {
  document.getElementById('examModal').style.display = 'block';
};

document.querySelector('.close').onclick = function() {
  document.getElementById('examModal').style.display = 'none';
};

window.onclick = function(event) {
  const modal = document.getElementById('examModal');
  if (event.target == modal) {
    modal.style.display = 'none';
  }
};


document.getElementById('openModal2Btn').onclick = function() {
  document.getElementById('sessionModal').style.display = 'block';
};

document.querySelector('.close').onclick = function() {
  document.getElementById('sessionModal').style.display = 'none';
};

window.onclick = function(event) {
  const modal2 = document.getElementById('sessionModal');
  if (event.target == modal2) {
    modal2.style.display = 'none';
  }
};


 // get the modal and close button for exam
  const modal = document.getElementById('examModal');
  const closeBtn = modal.querySelector('.close');

  // close modal when the X is clicked
  closeBtn.onclick = function () {
    modal.style.display = 'none';
  };
  
  // get the modal and close button for session
  const modal2 = document.getElementById('sessionModal');
  const closeBtn2 = modal2.querySelector('.close');
  
  // close modal when the X is clicked
  closeBtn2.onclick = function () {
    modal2.style.display = 'none';
  };

  // close modal when clicking outside of it
  window.onclick = function (event) {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  };
  
  async function loadUserData() {
      const res = await fetch('loadUser.php');
      const data = await res.json();

      const container = document.getElementById('userData');
      container.innerHTML = `
        <p><strong>ID:</strong> ${data.studentID} </p>
        <p><strong>Name:</strong> ${data.fname} ${data.lname}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
`       ;

      

      const tbody = document.getElementById('sessionTable');
      data.sessions.forEach(s => {
        const row = `<tr><td>${s.subject}</td><td>${s.date}</td><td>${s.time}</td></tr>`;
        tbody.innerHTML += row;
      });
    }

    loadUserData();
