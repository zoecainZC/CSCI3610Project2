<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'dbFuncs.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $fname = trim($_POST["fname"]);
    $lname = trim($_POST["lname"]);
    $phone = trim($_POST["phone"]);
    $password = trim($_POST["password"]);

    // Validate inputs
    if (empty($email) || empty($fname) || empty($lname) || empty($phone) || empty($password)) {
        $error = "All fields are required!";
    } else {
        try {
            $pdo = connectDB(); 
            $query = "SELECT * FROM students WHERE email = :email";
            $stmt = $pdo->prepare($query);
            $stmt->execute(['email' => $email]);

            if ($stmt->rowCount() > 0) {
                $error = "Email is already registered!";
            } else {
                // Hash password
                $hashed_password = sha1($password); 
                
                // Insert user into the db
                $query = "INSERT INTO students (email, fname, lname, phone, password, level) VALUES (:email, :fname, :lname, :phone, :password, 1)";
                $stmt = $pdo->prepare($query);
                $stmt->execute([
                    'email' => $email,
                    'fname' => $fname,
                    'lname' => $lname,
                    'phone' => $phone,
                    'password' => $hashed_password
                ]);
                
                // Redirect to login page 
                header("Location: login.php?signup=success");
                exit;
            }
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

include("pageFormat.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <script type="text/javascript">
        function validateEmail(id) {
            let email = id.value;
            let msgId = document.getElementById("emailMsg");
            let good = false;

            if (/^[A-Za-z0-9.-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email)) {
                good = true;
                msgId.innerHTML = "";
            } else {
                good = false;
                msgId.innerHTML = "Please enter a valid email";
            }

            return good;
        }

        function validatePassword(id) {
            let password = id.value;
            let msgId = document.getElementById("passwordMsg");
            let good = false;

            if (password.length < 6) {
                msgId.innerHTML = "Password must be at least 6 characters.";
            } else if (/^[A-Za-z]+$/.test(password)) {
                msgId.innerHTML = "Password cannot be only letters.";
            } else if (/^\d+$/.test(password)) {
                msgId.innerHTML = "Password cannot be only numbers.";
            } else {
                msgId.innerHTML = "";
                good = true;
            }

            return good;
        }

        function validate() {
            let eId = document.getElementById("email");
            let pId = document.getElementById("password");
            let submit = validateEmail(eId) && validatePassword(pId);

            if (!submit) {
                document.getElementById("formMsg").innerHTML = "Please fix the errors above.";
            } else {
                document.getElementById("formMsg").innerHTML = "";
            }

            return submit;
        }
    </script>
</head>
<style type="text/css">
    .btn {
        text-align: center;
        text-decoration: none;
        background-color: #2e7d32;
        color: white;
        padding: 12px 25px;
        border-radius: 10px;
        font-size: 18px;
        font-weight: bold;
        transition: background 0.3s ease, transform 0.2s ease;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .btn:hover{
        background-color: #b6e2a1; 
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15); 
    }

    a {
        color: #2e7d32;
    }

    a:hover {
        color: #b6e2a1;
    }

    header {
        background: linear-gradient(to right, #b6e2a1, #2e7d32);
        color: white;
        padding: 5px 0;
        text-align: center;
    }

    h1 {
        font-size: 70px;
        font-family: Georgia;
    }

    h2 {
        font-family: Georgia;
    }

    h3 {
        font-family: Georgia;
        font-size: 20px;
        font-weight: normal;
    }

    p {
        font-family: Georgia;
        font-size: 20px;
    }

    nav ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
    }

    nav ul li {
        margin: 0 25px;
    }

    nav ul li a {
        color: white;
        text-decoration: none;
        font-weight: bold;
        font-family: Georgia;
        font-size: 20px;
    }

    nav ul li a:hover {
        color: #b6e2a1;
    }

</style>
<body>
    <?php pageHeader("Ray's Tutoring"); ?>

    <div class="container">
        <br>
        <h2>Sign Up</h2>
        <?php if (isset($error)) echo "<p class='text-danger'>$error</p>"; ?>

        <form action="signup.php" method="POST" onsubmit="return validate()">
            <div class="form-group">
                <label for="fname">First Name:</label>
                <input type="text" name="fname" class="form-control" id="fname" placeholder="Enter first name">
            </div>
            <div class="form-group">
                <label for="lname">Last Name:</label>
                <input type="text" name="lname" class="form-control" id="lname" placeholder="Enter last name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" onblur="validateEmail(this)">
                <p id="emailMsg" class="text-danger"></p>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" name="phone" class="form-control" id="phone" placeholder="Enter phone">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Password" onblur="validatePassword(this)">
                <p id="passwordMsg" class="text-danger"></p>
            </div>
            <button type="submit" class="btn">Sign Up</button>
            <p id="formMsg" class="text-danger"></p>
        </form>

        <br>
        <p>Already have an account? Login <a href="login.php">here</a></p>
        <a href="./index.php">Back To Home</a> 
    </div>
    <br><br>
</body>
</html>
