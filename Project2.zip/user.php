<?php
session_start();
if (!isset($_SESSION['fname'])) {
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='UTF-8'>
      <title>User Profile</title>
    </head>
    <body style='font-family: Georgia; padding: 20px; background-color: #f4f4f4;'>
      <div style='background: white; padding: 20px; border-radius: 8px;'>
        <h1>Please log in to view your profile.</h1>
        <a href='login.php'>Login</a>
      </div>
    </body>
    </html>";
    exit;
}
include("pageFormat.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Profile</title>
  <style>
  body {
  margin: 0;
  padding: 0;
  font-family: Georgia;
  background-color: #f4f4f4;
}

  .btn-primary {
        text-align: center !important;
        text-decoration: none !important;
        background-color: #2e7d32 !important; 
        color: white !important;
        padding: 10px 20px !important;
        border-radius: 10px !important;
        font-size: 18px !important;
        font-weight: bold !important;
        font-family: Georgia !important;
        transition: background 0.3s ease !important;
        border: none !important;
        cursor: pointer !important;
        margin-bottom:20px !important;
        }
        
        .btn-primary:hover {
        background-color: #b6e2a1 !important;
      }
      
      header {
      background: linear-gradient(to right, #b6e2a1, #2e7d32);
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    
    a {
        color: #2e7d32;
    }
    
    a:hover {
        color: #b6e2a1;
    }

    h1 {
      font-size: 80px;
      font-family: Georgia;
    }

    h2 {
      font-family: Georgia;
    }

    h3 {
      font-family: Georgia;
      font-size: 20px;
      font-weight: normal;
    }

    p {
      font-family: Georgia;
      font-size: 20px;
    }

    nav {
      background: rgba(0, 0, 0, 0.1);
      padding: 15px 0;
    }

    nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
    }
    
    nav ul li {
      margin: 0 25px;
    }
    
    nav ul li a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-family: Georgia;
      font-size: 20px;
    }
    
    nav ul li a:hover {
      color: #b6e2a1; /* soft green on hover */
    }
    
    h3 {
        font-size: 40px;
        font-weight: bold;
    }
    
    .text-container {
      max-width: 800px; /* or whatever width you prefer */
      margin: 0 auto;
      text-align: left; /* optional: keep text left-aligned inside the container */
    }
    
    
    table {
      width: 100%; border-collapse: collapse; margin-top: 20px;
    }
    
    th, td { 
      border: 1px solid #ccc; padding: 10px; 
    }
    
    footer {
      background: linear-gradient(to right, #b6e2a1, #2e7d32);
      color: white;
      text-align: center;
      padding: 50px 0;
      width: 100%;
    }
    
    footer p {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px; /* controls spacing between items */
  font-size: 20px;
  margin: 0;
}

  </style>
</head>
<body>
      <?php pageHeader("Ray's Tutoring"); ?>
<br><br>
    
  <div class="text-container">
    <h3>Welcome, <?php echo htmlspecialchars($_SESSION['fname']); ?></h3><br>

    <div id="userData"></div><br><br>

    <h2>Your Schedule</h2>
    <table>
      <thead>
        <tr><th>Session Name</th><th>Date</th><th>Time</th></tr>
      </thead>
      <tbody id="sessionTable"></tbody>
    </table>
  </div>

  <script>
    async function loadUserData() {
      const res = await fetch('loadUser.php');
      const data = await res.json();

      const container = document.getElementById('userData');
      container.innerHTML = `
        <p><strong>Name:</strong> ${data.fname} ${data.lname}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
`       ;

      

      const tbody = document.getElementById('sessionTable');
      data.sessions.forEach(s => {
        const row = `<tr><td>${s.title}</td><td>${s.date}</td><td>${s.time}</td></tr>`;
        tbody.innerHTML += row;
      });
    }

    loadUserData();
  </script>
  <br><br><br>
  
  <!-- Button to Open Modal -->
<div class="container m-5" style="justify-self: center">
    <div class="d-flex flex-wrap  gap-2" style="justify-content: center; align-items: center; width: 100%">
       <button class="btn-primary quoteButton" data-bs-toggle="modal" data-bs-target="#quoteModal" style="font-weight: bold; padding: 0.75em; display: flex;">
    <h2 class="m-1 p-0 text-center align-bottom" style="display: flex; justify-content: center; align-items: center; text-align: center; font-family: Oswald;">
        Schedule a Session
    </h2>
</button>

    </div>
</div>

<!-- Include Bootstrap and FontAwesome (if not already included) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.6.0/css/all.min.css">

<!-- Paste the entire modal here (everything inside <div class="modal fade" id="quoteModal"> ... </div>) -->
<?php include('form.php'); ?>

 <?php pageFooter(); ?>

</body>
</html>
