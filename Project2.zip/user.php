<?php

session_start();

if (!isset($_SESSION['fname'])) {
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='UTF-8'>
      <title>User Profile</title>
    </head>
    <body style='font-family: Georgia; padding: 20px; background-color: #f4f4f4;'>
      <div style='background: white; padding: 20px; border-radius: 8px;'>
        <h1>Please log in to view your profile.</h1>
        <a href='login.php'>Login</a>
      </div>
    </body>
    </html>";
    exit;
}

$userDetails = [];
if (isset($_SESSION['fname'])) {
    require_once("dbFuncs.php");
    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("SELECT fname, lname, studentID, email, phone FROM students WHERE fname = ?");
        $stmt->execute([$_SESSION['fname']]);
        $userDetails = $stmt->fetch();
    } catch (Exception $e) {
        $userDetailsError = "Error fetching user details: " . $e->getMessage();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['examName'])) {
    require_once("dbFuncs.php");
    $examName = $_POST['examName'];
    $class = $_POST['class'];
    $examDate = $_POST['examDate'];
    $fname = $_SESSION['fname'];

    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("INSERT INTO exams (examName, class, examDate, fname) VALUES (?, ?, ?, ?)");
        $stmt->execute([$examName, $class, $examDate, $fname]);

        $success = "Exam submitted successfully!";
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['date'])) {
    require_once("dbFuncs.php");
    $date = $_POST['date'];
    $time = $_POST['time'];
    $subject = $_POST['subject'];
    $fname = $_SESSION['fname'];

    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("INSERT INTO sessions (date, time, subject, fname) VALUES (?, ?, ?, ?)");
        $stmt->execute([$date, $time, $subject, $fname]);

        $success = "Session submitted successfully!";
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}


$exams = [];
require_once("dbFuncs.php");
try {
    $pdo = connectDB();
    $stmt = $pdo->prepare("SELECT examName, class, examDate FROM exams WHERE fname = ?");
    $stmt->execute([$_SESSION['fname']]);
    $exams = $stmt->fetchAll();
} catch (Exception $e) {
    $examError = "Failed to fetch exams: " . $e->getMessage();
}

$sessionsForAdmin = [];
if (isset($_SESSION['level']) && $_SESSION['level'] == 10) {
    try {
        $stmt = $pdo->query("SELECT fname, date, time, subject FROM sessions");
        $sessionsForAdmin = $stmt->fetchAll();
    } catch (Exception $e) {
        $sessionError = "Failed to fetch sessions: " . $e->getMessage();
    }
}

if (isset($_POST['deleteSession'])) {
    // check if user is level 10
    if (isset($_SESSION['level']) && $_SESSION['level'] == 10 && isset($_POST['fname'])) {
        $fname = $_POST['fname'];
        
        // deletion from the database
        try {
            $pdo = connectDB();
            $stmt = $pdo->prepare("DELETE FROM sessions WHERE fname = ?");
            $stmt->execute([$fname]);
        } catch (Exception $e) {
            $deleteError = "Error deleting session: " . $e->getMessage();
        }
    }
}

if (isset($_POST['deleteExam'])) {
    if (isset($_SESSION['fname']) && isset($_POST['examName']) && isset($_POST['examDate'])) {
        $examName = $_POST['examName'];
        $examDate = $_POST['examDate'];
        $fname = $_SESSION['fname'];

        try {
            $pdo = connectDB();
            $stmt = $pdo->prepare("DELETE FROM exams WHERE examName = ? AND examDate = ? AND fname = ?");
            $stmt->execute([$examName, $examDate, $fname]);

            $deleteExamSuccess = "Exam deleted successfully!";
        } catch (Exception $e) {
            $deleteExamError = "Error deleting exam: " . $e->getMessage();
        }
    }
}

$userSessions = [];
if (isset($_SESSION['level']) && $_SESSION['level'] == 1) {
    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("SELECT fname, date, time, subject FROM sessions WHERE fname = ?");
        $stmt->execute([$_SESSION['fname']]); 
        $userSessions = $stmt->fetchAll();
    } catch (Exception $e) {
        $userSessionError = "Failed to fetch your sessions: " . $e->getMessage();
    }
}

include("pageFormat.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Profile</title>
  <link rel="stylesheet" href="user.css">
</head>
<body>
      <?php pageHeader("Ray's Tutoring"); ?>
<br>
  <div class="card-container">
  
    <div class="card">
    <div id="studyTip" style="padding: 10px; background-color: #e8f5e9; color: #2e7d32; font-family: Georgia; font-size: 20px; text-align: center;" ></div>
    </div>

    <div class="card">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['fname']); ?>!</h2><br>
    
    <button class='edit-button' onclick='openPopup()' style="width: 20%;">Edit Profile</button><br>
    
    
    <div id="userData">
        <?php if (!empty($userDetails)): ?>
        <p><strong>Student ID:</strong> <?php echo htmlspecialchars($userDetails['studentID']); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($userDetails['fname']." ".$userDetails['lname']); ?></p>
        <p><strong>Email:</strong><span id="display-email"> <?php echo htmlspecialchars($userDetails['email']); ?></span></p>
        <p><strong>Phone:</strong><span id="display-phone"><?php echo htmlspecialchars($userDetails['phone']); ?></span></p>
        <?php else: ?>
        <p>User details not found.</p>
        <?php endif; ?>
    </div>
    </div>
    
    <!-- ***** EDIT PROFILE POPUP ***** -->
    <div class="popup-overlay" id="popup-overlay">
      <div class="popup-content">
        <h2>Edit Profile</h2>
        <form onsubmit="submitProfileEdit(event)">
          <label for="email">Email</label>
          <input type="email" id="edit-email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" required>

          <label for="phone">Phone</label>
          <input type="text" id="edit-phone" name="phone" placeholder="Phone" value="<?php echo htmlspecialchars($_SESSION['phone']); ?>" required>

          <button type="submit">Save Changes</button>
          <button type="button" class="close-button" onclick="closePopup()">Cancel</button>
        </form>
      </div>
    </div>

    
    <?php if (isset($_SESSION['level']) && $_SESSION['level'] == 1): ?>
    <div class="card">
    <h2>Your Sessions</h2>
    <?php if (!empty($userSessions)): ?>
        <table border="1" cellpadding="8" style="background-color: white; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Subject</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($userSessions as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['date']); ?></td>
                        <td><?php echo htmlspecialchars($s['time']); ?></td>
                        <td><?php echo htmlspecialchars($s['subject']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No sessions found.</p>
    <?php endif; ?>
    
    <?php if (isset($userSessionError)): ?>
        <p style="color: red;"><?php echo $userSessionError; ?></p>
    <?php endif; ?>
     <!-- ***** SCHEDULE SESSION BUTTON ***** -->
  
  <div style="text-align: center; margin-top: 20px;">
        <button id="openModal2Btn" style="background-color: green; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-size: 18px;">
            Schedule a Session
        </button>
  </div>
    </div>
<?php endif; ?>

    
    <div class="card">
    <h2>Coming up:</h2><br>
    <?php if (!empty($exams)): ?>
    <table id="examTable" style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr>
                <th>Exam Name</th>
                <th>Class</th>
                <th>Exam Date</th>
                <th>Countdown</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($exams as $exam): ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($exam['examName']); ?></strong></td>
                <td><em><?php echo htmlspecialchars($exam['class']); ?></em></td>
                <td>
                    <span class="exam-date" data-date="<?php echo htmlspecialchars($exam['examDate']); ?>">
                        <?php echo htmlspecialchars($exam['examDate']); ?>
                    </span>
                </td>
                <td><span class="countdown"></span></td>
                <td>
                    <form method="POST" action="">
                    <input type="hidden" name="examName" value="<?php echo htmlspecialchars($exam['examName']); ?>">
                    <input type="hidden" name="examDate" value="<?php echo htmlspecialchars($exam['examDate']); ?>">
                    <button type="submit" name="deleteExam" style="background-color: red; color: white; border: none; padding: 5px 10px; border-radius: 5px;">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>No exams found.</p>
    <?php endif; ?><br><br><br>

    <div style="text-align: center; margin-top: 20px;">
        <button id="openModalBtn" style="background-color: green; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-size: 18px;">
            Add Exam
        </button>
    </div>
    </div>
    
    <?php if (isset($_SESSION['level']) && $_SESSION['level'] == 10): ?>
    <div class="card">
    <h2>All Sessions</h2>
    <?php if (!empty($sessionsForAdmin)): ?>
        <table border="1" cellpadding="8" style="background-color: white; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Subject</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sessionsForAdmin as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['fname']); ?></td>
                        <td><?php echo htmlspecialchars($s['date']); ?></td>
                        <td><?php echo htmlspecialchars($s['time']); ?></td>
                        <td><?php echo htmlspecialchars($s['subject']); ?></td>
                        <td>
                                <form method="POST" action="">
                                    <input type="hidden" name="fname" value="<?php echo $s['fname']; ?>" />
                                    <button type="submit" name="deleteSession" style="background-color: red; color: white; border: none; padding: 5px 10px; border-radius: 5px;">
                                        Delete
                                    </button>
                                </form>
                            </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No sessions found.</p>
    <?php endif; ?>

        <?php if (isset($deleteSuccess)): ?>
            <p style="color: green;"><?php echo $deleteSuccess; ?></p>
        <?php elseif (isset($deleteError)): ?>
            <p style="color: red;"><?php echo $deleteError; ?></p>
        <?php endif; ?>
<?php endif; ?>
  </div>
  </div>
  <br>
  
<!-- include Bootstrap and FontAwesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.6.0/css/all.min.css">

 <?php pageFooter(); ?>
 
 <!-- Exam Submission Form -->
<!-- Modal -->
<div id="examModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.5);">
  <div class="modal-content" style="background-color: #fff; margin: 10% auto; padding: 20px; border-radius: 12px; width: 400px; max-width: 90%; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); position: relative;">

    <span class="close" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;" onmouseover="this.style.color='black'" onmouseout="this.style.color='#aaa'">&times;</span>
    <h4 style="color: #2e7d32; font-family: Georgia;">Add Exam</h4>
    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST" action="">
      <label for="examName" style="font-family: Georgia;">Exam Name:</label><br>
      <input type="text" name="examName" required><br>

      <label for="class" style="font-family: Georgia;">Class:</label><br>
      <input type="text" name="class" required><br>

      <label for="examDate" style="font-family: Georgia;">Date:</label><br>
      <input type="date" name="examDate" required><br><br>

      <input type="submit" value="Submit" style="font-family: Georgia; background-color: #2e7d32; color: white; font-size: 20px;">
    </form>
  </div>
</div>

<!-- Session Submission Form -->
<!-- Modal -->
<div id="sessionModal" class="modal2" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.5);">
  <div class="modal-content" style="background-color: #fff; margin: 10% auto; padding: 20px; border-radius: 12px; width: 400px; max-width: 90%; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); position: relative;">

    <span class="close" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;" onmouseover="this.style.color='black'" onmouseout="this.style.color='#aaa'">&times;</span>
    <h4 style="color: #2e7d32; font-family: Georgia;">Schedule a Session</h4>
    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST" action="">
      <label for="date" style="font-family: Georgia;">Date:</label><br>
      <input type="date" name="date" required><br>

      <label for="time" style="font-family: Georgia;">Time:</label><br>
      <input type="time" name="time" required><br>

      <label for="subject" style="font-family: Georgia;">Subject:</label><br>
      <input type="text" name="subject" required><br><br>

      <input type="submit" value="Submit" style="font-family: Georgia; background-color: #2e7d32; color: white; font-size: 20px;">
    </form>
  </div>
</div>
 
<script src="user.js"></script>


</body>
</html>