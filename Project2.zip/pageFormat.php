<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function pageHeader($title = "Ray's Tutoring") {
  $isLoggedIn = isset($_SESSION['fname']);
  $loginText = $isLoggedIn ? "Logout" : "Login";
  $loginHref = $isLoggedIn ? "logout.php" : "login.php";
  $welcome = $isLoggedIn ? "<p style='color: black !important; font-weight: bold; font-size: 20px;'>Welcome, " . htmlspecialchars($_SESSION['fname']) . "!</p>" : "";

  echo <<<EOT
  
  $welcome
  
  <header>
    <h1>$title</h1>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="signup.php">Sign Up</a></li>
        <li><a href="learnMore.php">Learn More</a></li>
        <li><a href="$loginHref">$loginText</a></li>
        <li><a href="user.php">Profile</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
EOT;
}

function pageFooter() {
  echo <<<EOT
  </main>
  <footer>
    <p>
      Ray's Tutoring © 2025
      <span class="separator">|</span>
      Phone: 123-456-7890
      <span class="separator">|</span>
      Email: raystutoring@example.com
    </p>
  </footer>
</body>
</html>
EOT;
}
?>
