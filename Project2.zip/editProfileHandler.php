<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// DEBUG: Output only JSON
header('Content-Type: application/json');

// Catch fatal errors
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null) {
        echo json_encode(['success' => false, 'message' => 'Fatal error: ' . $error['message']]);
    }
});



session_start();
header('Content-Type: application/json');

try {
    if (!isset($_SESSION["fname"])) {
        throw new Exception('User not logged in');
    }

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        throw new Exception('Invalid request method');
    }

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }

    $email = filter_var(trim($input['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    $phone = htmlspecialchars(trim($input['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
    if (empty($phone)) {
        throw new Exception('Phone number is required');
    }


    $password = $input['password'] ?? null;

    $conn = new mysqli("localhost", "u475018128_cainz", "PHPuser@1234", "u475018128_tutoring");
    if ($conn->connect_error) {
        throw new Exception('Database connection failed: ' . $conn->connect_error);
    }

    $sql = "UPDATE students SET email = ?, phone = ?";
    $types = "ss";
    $params = [$email, $phone];

    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = ?";
        $types .= "s";
        $params[] = $hashedPassword;
    }

    $sql .= " WHERE fname = ?";
    $types .= "s";
    $params[] = $_SESSION["fname"];

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . $conn->error);
    }

    $stmt->bind_param($types, ...$params);
    if (!$stmt->execute()) {
        throw new Exception('Failed to execute statement: ' . $stmt->error);
    }

    $_SESSION["emails"] = $email;
    $_SESSION["phone"] = $phone;

    echo json_encode(['success' => true, 'message' => 'Profile updated successfully'], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($stmt)) $stmt->close();
    if (isset($conn)) $conn->close();
}
?>